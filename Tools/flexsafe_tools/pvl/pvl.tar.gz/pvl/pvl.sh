#!/bin/bash
shopt -s  expand_aliases
alias lv='/usr/share/lvm_command/lv/lv.sh /usr/share/lvm_command/lv'
alias pv='/usr/share/lvm_command/pv/pv.sh /usr/share/lvm_command/pv'
alias vg='/usr/share/lvm_command/vg/vg.sh /usr/share/lvm_command/vg'

is_pvled=$(lv -d | grep "Logical volume")
if [[ "$is_pvled" != "" ]]
then
    echo -e "\E[1;31m 逻辑卷已存在！ \n \E[0m"
    echo -e "\E[1;31m 请手动检查！ \n \E[0m"
    echo -e "\E[1;31m 程序退出！ \n \E[0m"
    exit 1
fi
#显示所有磁盘
echo -e "\E[1;31m ***************磁盘列表*************** \n \E[0m"
fdisk -l | grep "Disk /" | awk -F '[, ]+' '{print $2 $3 $4}'
echo -e "\E[1;31m ***************磁盘列表*************** \n \E[0m"
echo -e '\n\n'

#使用fdisk划盘
#read -p "请输入磁盘号，默认值为：/dev/sda:" disk_name
#if [[ $disk_name == "" ]];then
#    disk_name="/dev/sda"
#fi

#获取最后一行的硬盘名
disk_name=`fdisk -l | grep "Disk /" | awk 'END {print}' | awk -F '[ :]+' '{print $2}'`

#获取对应硬盘的容量单位符号（T、G）


echo -e "\E[1;31m --------使用fdisk分区中-------- \n \E[0m"
echo -e "n\np\n\n\n\nw" | fdisk $disk_name
echo -e "\E[1;31m 分区完成，新建分区： \n \E[0m"
fdisk -l | grep $disk_name | awk 'END {print}'
echo -e '\n\n'

#安装parted
echo -e "\E[1;31m ***************安装parted*************** \n \E[0m"
rm -fr /var/lib/dpkg/lock
dpkg -i ./libparted2_3.2-15ubuntu0.1_amd64.deb
dpkg -i ./parted_3.2-15ubuntu0.1_amd64.deb
partprobe
echo -e "\E[1;31m ***************完成parted安装*************** \n \E[0m"
echo -e '\n\n'

#lvm
echo -e "\E[1;31m ---------------开始lvm划盘--------------- \n \E[0m"
part_name=`fdisk -l | grep $disk_name | awk 'END {print}' | awk -F '[ :]+' '{print $1}'`
echo -e "\E[1;31m 逻辑卷分区：$part_name \n \E[0m"

echo "----start pv----"
pv -c $part_name
echo "----end pv----"
echo -e '\n\n'
echo "----start vg----"
vg -c data $part_name
echo "----end vg----"
sleep 2

symbol=`vg -d | grep "VG Size" | awk 'END {print $4}' | cut -d "i" -f1`
vg_size=`vg -d | grep "VG Size" | awk 'END {print $3}'`
new_vg_size=`echo | awk "{print $vg_size-0.1}"`
echo -e "\E[1;31m 逻辑卷大小：${new_vg_size}${symbol}  \n \E[0m"

echo -e "y\n" | lv -c ${new_vg_size}${symbol} volume data

echo -e "\E[1;31m ---------------lvm划盘结束--------------- \n \E[0m"
echo -e "\E[1;31m 逻辑盘详情： \n \E[0m"
lvdisplay
